﻿using Diplom.ApplicationData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Diplom.PageAdmin
{
    /// <summary>
    /// Логика взаимодействия для Events.xaml
    /// </summary>
    public partial class Events : Page
    {
        public Events()
        {
            InitializeComponent();
            Event.ItemsSource = AppConnect.modelOdb.Events.ToList();
        }


        private void Event_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new PageAdmin1());
        }

        private void txtB_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtB.Text != "")
            {
                Event.ItemsSource = AppConnect.modelOdb.Events.Where(x => x.Name.ToLower().Contains(txtB.Text.ToLower()) || x.Theme.ToLower().Contains(txtB.Text.ToLower())).ToList();
            }
            else
            {
                Event.ItemsSource = AppConnect.modelOdb.Events.ToList();
            }
        }
    }
}
