﻿using Diplom.ApplicationData;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;

namespace Diplom.PageAdmin
{
    /// <summary>
    /// Логика взаимодействия для EditZakaz.xaml
    /// </summary>
    public partial class EditZakaz : Window
    {
        private DiplomBaseEntities _context = new DiplomBaseEntities();
        private int selectedZakaz;
        public EditZakaz(int selectedId)
        {
            InitializeComponent();
            selectedZakaz = selectedId;
            Material.ItemsSource = DiplomBaseEntities.GetContext().Materials.ToList();
            var Zakaz123 = _context.Zakaz.FirstOrDefault(f => f.idZakaz == selectedZakaz);
            DataContext = Zakaz123;
            var MaterialtName = _context.Materials.ToList();
            Material.ItemsSource = MaterialtName;
            Material.DisplayMemberPath = "Material";
            var UserName = _context.User.ToList();
            User.ItemsSource = UserName;
            User.DisplayMemberPath = "Name";
            var NNumberClient=_context.Client.ToList();
            NumberClient.ItemsSource= NNumberClient;
            NumberClient.DisplayMemberPath= "Name";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string Costyan = Cost.Text;
            string Adress = AdresName.Text;
            string Statuss = Status.Text;
            Materials category = Material.SelectedItem as Materials;
            Client NamberClients= NumberClient.SelectedItem as Client;
            User UserName = User.SelectedItem as User;
            int idClients = NamberClients.idClient;
            int Usesr = UserName.idUser;
            int mat = category.idMaterial;
            var Zakaz123 = _context.Zakaz.FirstOrDefault(f => f.idZakaz == selectedZakaz);
            Zakaz123.DateZamera=DateTime.Now;
            Zakaz123.Cost = Costyan;
            Zakaz123.Status = Statuss;
            Zakaz123.idClient = idClients;
            Zakaz123.idUser = Usesr;
            Zakaz123.Adress = Adress;
            Zakaz123.idMaterial = mat;
            _context.SaveChanges();
                MessageBox.Show("Данные сохранены!");
                AppFrame.frameMain.Navigate(new Spisoc());

        }

        private void FamiliyaTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void NameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void OtchestvoTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TelefoneTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void AdressTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_2(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_3(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_4(object sender, TextChangedEventArgs e)
        {

        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }

        private void Material_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }
    }
}
