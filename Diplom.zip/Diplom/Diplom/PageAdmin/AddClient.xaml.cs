﻿using Diplom.ApplicationData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom.PageAdmin
{
    /// <summary>
    /// Логика взаимодействия для AddClient.xaml
    /// </summary>
    public partial class AddClient : Window
    {
        private Client SelectClient = new Client();
        public AddClient()
        {
            InitializeComponent();
            if (SelectClient != null)
            {
            DataContext = SelectClient;
            }
        }

        private void SurnameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string name = NameTextBox.Text;
           string surename = SurnameTextBox.Text;
           string patronomic =PatronymicTextBox.Text;
           string phone= TelefoneTextBox.Text;
           string adress =AdressTextBox.Text;
           DiplomBaseEntities context = DiplomBaseEntities.GetContext();
            Client newClient = new Client();
            newClient.Name = name;
            newClient.Surname = surename;
            newClient.Patronymic = patronomic;
            newClient.Telefone = phone;
            newClient.Adress = adress;
            context.Client.Add(newClient);
            context.SaveChanges();
            MessageBox.Show("Данные сохранены!");
            AppFrame.frameMain.Navigate(new Catalog());
        }

        private void NameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void OtchestvoTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TelefoneTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void AdressTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
