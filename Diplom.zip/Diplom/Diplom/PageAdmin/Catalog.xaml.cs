﻿using Diplom.ApplicationData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Diplom.PageAdmin
{
    /// <summary>
    /// Логика взаимодействия для Catalog.xaml
    /// </summary>
    public partial class Catalog : Page
    {
        public Catalog()
        {
            InitializeComponent();
            Client.ItemsSource = AppConnect.modelOdb.Client.ToList();
            Client.ItemsSource = DiplomBaseEntities.GetContext().Client.ToList();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            AddClient editwin = new AddClient();
            editwin.ShowDialog();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new Catalog());
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var PaymForDel = Client.SelectedItems.Cast<Client>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить {PaymForDel.Count()} элемент(ов)?", "Внимание!", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                try
                {
                    Client.ItemsSource = DiplomBaseEntities.GetContext().Client.ToList();
                    DiplomBaseEntities.GetContext().Client.RemoveRange(PaymForDel);
                    DiplomBaseEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    AppFrame.frameMain.Navigate(new Catalog());
                }
                catch
                {
                    MessageBox.Show("Ошибка удаления данных!");

                }
            }
        }

            private void Button_Click_5(object sender, RoutedEventArgs e)
            {
                PrintDialog printDialog = new PrintDialog();
                if (printDialog.ShowDialog() == true)
                {
                    printDialog.PrintVisual(Client, "");
                }
                else
                {
                    MessageBox.Show("Пользователь прервал печать");
                }
            }

            private void Button_Click_3(object sender, RoutedEventArgs e)
            {
                AppFrame.frameMain.Navigate(new PageAdmin1());
            }

            private void Client_SelectionChanged(object sender, SelectionChangedEventArgs e)
            {

            }

            private void txtB_TextChanged(object sender, TextChangedEventArgs e)
            {
                if (txtB.Text != "")
                {
                    Client.ItemsSource = AppConnect.modelOdb.Client.Where(x => x.Name.ToLower().Contains(txtB.Text.ToLower()) || x.Name.ToLower().Contains(txtB.Text.ToLower()) || x.Surname.ToLower().Contains(txtB.Text.ToLower())).ToList();
                }
                else
                {
                    Client.ItemsSource = AppConnect.modelOdb.Client.ToList();
                }
            }
        }
    }

