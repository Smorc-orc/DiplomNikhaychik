﻿using Diplom.ApplicationData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Diplom.PageAdmin
{
    /// <summary>
    /// Логика взаимодействия для Spisoc.xaml
    /// </summary>
    public partial class Spisoc : Page
    {
        public Spisoc()
        {
            InitializeComponent();
            Zakaza.ItemsSource = AppConnect.modelOdb.Zakaz.ToList();
            Zakaza.ItemsSource = DiplomBaseEntities.GetContext().Zakaz.ToList();
           
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = Zakaza.SelectedItem;
            if (selectedItem==null)
            {
                AddZakaz addwin = new AddZakaz();
                addwin.ShowDialog();
            }
            else
            {
                var selectedId = (int)selectedItem.GetType().GetProperty("idZakaz").GetValue(selectedItem);
                EditZakaz editwin = new EditZakaz(selectedId);
                editwin.ShowDialog();
            }
        }

        private void txtB_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtB.Text != "")
            {
                Zakaza.ItemsSource = AppConnect.modelOdb.Zakaz.Where(x => x.Status.ToLower().Contains(txtB.Text.ToLower())).ToList();
            }
            else
            {
                Zakaza.ItemsSource = AppConnect.modelOdb.Zakaz.ToList();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new Spisoc());
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var PaymForDel = Zakaza.SelectedItems.Cast<Zakaz>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить {PaymForDel.Count()} элемент(ов)?", "Внимание!", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                try
                {
                    Zakaza.ItemsSource = DiplomBaseEntities.GetContext().Zakaz.ToList();
                    DiplomBaseEntities.GetContext().Zakaz.RemoveRange(PaymForDel);
                    DiplomBaseEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    AppFrame.frameMain.Navigate(new Spisoc());
                }
                catch
                {
                    MessageBox.Show("Ошибка удаления данных!");

                }
            }
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            if (printDialog.ShowDialog() == true)
            {
                printDialog.PrintVisual(Zakaza, "");
            }
            else
            {
                MessageBox.Show("Пользователь прервал печать");
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new PageAdmin1());
        }

        private void Client_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
