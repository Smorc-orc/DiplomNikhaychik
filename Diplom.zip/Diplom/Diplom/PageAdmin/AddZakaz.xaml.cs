﻿using Diplom.ApplicationData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom.PageAdmin
{
    /// <summary>
    /// Логика взаимодействия для AddZakaz.xaml
    /// </summary>
    public partial class AddZakaz : Window
    {
        private DiplomBaseEntities _context = new DiplomBaseEntities();
        public AddZakaz()
        {
            InitializeComponent();
            Material.ItemsSource = DiplomBaseEntities.GetContext().Materials.ToList();
            var MaterialtName = _context.Materials.ToList();
            Material.ItemsSource = MaterialtName;
            Material.DisplayMemberPath = "Material";
            var UserName = _context.User.ToList();
            User.ItemsSource = UserName;
            User.DisplayMemberPath = "Name";
            var NNumberClient = _context.Client.ToList();
            NumberClient.ItemsSource = NNumberClient;
            NumberClient.DisplayMemberPath = "Name";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string Costyan = Cost.Text;
            string Adress = AdresName.Text;
            string Statuss = Status.Text;
            Materials category = Material.SelectedItem as Materials;
            Client NamberClients = NumberClient.SelectedItem as Client;
            User UserName = User.SelectedItem as User;
            int idClients = NamberClients.idClient;
            int Usesr = UserName.idUser;
            int mat = category.idMaterial;
                Zakaz tovar = new Zakaz
                {
                    DateZamera = DateTime.Now,
                    Cost = Costyan,
                    Status = Statuss,
                    idClient = idClients,
                    idUser = Usesr,
                    Adress = Adress,
                    idMaterial = mat,
                };
                _context.Zakaz.Add(tovar);
                _context.SaveChanges();
                MessageBox.Show("Данные сохранены!");
                AppFrame.frameMain.Navigate(new Spisoc());
        }

        private void FamiliyaTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void NameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void OtchestvoTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TelefoneTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void AdressTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_2(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_3(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_4(object sender, TextChangedEventArgs e)
        {

        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Material_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}

