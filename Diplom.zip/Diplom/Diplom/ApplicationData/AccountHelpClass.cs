﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diplom.ApplicationData
{
    internal class AccountHelpClass
    {
        public static int id { get; set; }
    }
}
